
package ems;

public class Department {
    

   private String deptName,depCode;

    public String getDeptName() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    public String getDepCode() {
        return depCode;
    }

    public void setDepCode(String depCode) {
        this.depCode = depCode;
    }

    public Department(String deptName, String depCode) {
        this.deptName = deptName;
        this.depCode = depCode;
    }
   
   
}
