
package ems;

public class Attendance {
   
    private int employeeID;

    public int getEmployeeID() {
        return employeeID;
    }

    public void setEmployeeID(int employeeID) {
        this.employeeID = employeeID;
    }

    public Attendance(int employeeID) {
        this.employeeID = employeeID;
    }
    
    
    
   
}
