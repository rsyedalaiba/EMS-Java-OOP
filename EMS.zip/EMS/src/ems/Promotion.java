
package ems;

public class Promotion {
     private Employee e;
     private SalariedEmployee se;
     private CommissionedEmployee ce;
     private BasePlusCommissionEmployee be;
     private EmployeePerformance ep;

    public Promotion(SalariedEmployee se, CommissionedEmployee ce, BasePlusCommissionEmployee be, EmployeePerformance ep) {
        
        
        this.se = se;
        this.ce = ce;
        this.be = be;
        this.ep = ep;
    }
    public Employee getE() {
        return e;
    }

    public void setE(Employee e) {
        this.e = e;
    }
    
//    public int CalculateAciveYears()
//    {
//        if(this.se.getTypeOfEmployee() == "Salaried")
//        { int activeYears=se.currentYear-se.getEmpYearOfJoining();
//          return activeYears;}
//        else if(this.ce.getTypeOfEmployee() == "Commissioned")
//        {
//          int activeYears=ce.currentYear-ce.getEmpYearOfJoining();
//          return activeYears;  
//        }
//        else if(this.be.getTypeOfEmployee() =="Base Plus Commission")
//        {
//          int activeYears=be.currentYear-be.getEmpYearOfJoining();
//          return activeYears;  
//        }
//        return 0;
//    }
//    public String Increment()
//    {
//        if(this.se.getTypeOfEmployee() == "Salaried")
//        {
//            if(this.CalculateAciveYears()>=3 && this.ep.count>=2)
//            {
//                return  "\n---Promotion---\n"+
//                        "\n-Designation: "+
//                       "\n-Increment in Salary: "+this.se.getBasicSalary()*0.2+
//                        "\n-New Salary: "+this.se.CalculateNetSalary();
//            }
//        }
//        else if(this.ce.getTypeOfEmployee() == "Commissioned")
//        {
//            if(this.ce.getGrossSales()>500 && this.ep.count >5)
//            {                
//                return "\n---Promotion---\n"+
//                        "\n-Designation: "+
//                       "\n-Increment: "+this.ce.Commission() *0.2+
//                       "\n-New Salary: "+this.ce.Commission();
//                
//            }
//        }
//        else if(this.be.getTypeOfEmployee() == "Base Plus Commission")
//        {
//            if(this.ce.getGrossSales()>500 && this.CalculateAciveYears()>=5 )
//            {
//               return  "\n---Promotion---\n"+
//                       "Designation: "+
//                       "Increment: "+this.be.Commission() *0.2+
//                       "New Salary: "+this.be.CalculateNetSalary(); 
//            }
//        }
//               return "No Increment in Salary.";
//    }
}
