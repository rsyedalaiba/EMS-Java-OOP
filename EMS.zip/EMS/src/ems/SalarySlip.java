
package ems;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class SalarySlip implements SalaryInformation{
    private double basicSalary;
    private double grossSales,commissionRate;
    
    ConnectionToDB con=new ConnectionToDB();
    Connection con_obj=con.EstablishConnection();
    Statement st=null;
    PreparedStatement ps=null;
    ResultSet rs=null;

    

    public double setBasicSalary(double basicSalary) {
        if(basicSalary>0)
        {this.basicSalary = basicSalary;
        return basicSalary;
        }
       
//        return basicSalary;
        else
         System.out.println("Invalid Input");
        
        return 0.0;

    }
    public double getBasicSalary() {
        return this.basicSalary;
    }

    public double getGrossSales() {
        return grossSales;
    }

    public double setGrossSales(double grossSales) {
        this.grossSales = grossSales;
        return grossSales;
    }

    public double getCommissionRate() {
        return commissionRate;
    }

    public double setCommissionRate(double commissionRate) {
        this.commissionRate = commissionRate;
        return commissionRate;
    }

    
    @Override
    public double CalculateMedicalAllowance(double basicSalary) {

        return (setBasicSalary(basicSalary)*0.1);
    }

    @Override
    public double CalculateConveyanceAllowance(double basicSalary) {
        return  (setBasicSalary(basicSalary)*0.15);
    }

//    double GS=CalculateMedicalAllowance(basicSalary)+CalculateConveyanceAllowance(basicSalary);
    @Override
    public double CalculateGrossSalaray(double basicSalary,double MS,double CA) {
        return setBasicSalary(basicSalary)+MS+CA;
        
    }

    @Override
    public double CalculateAnnualSalary(double GS) {
       return GS*12;
    }

    @Override
    public double CalculateProvidentFund(double GS) {
        return ((GS -0.01)/12);
    }

    @Override
    public double CalculateDeductions(double Tax,double PF) {
        return (Tax+PF);
    }

    @Override
    public double CalculateNetSalary(double GS,double d) {
        return (GS - d);
    }

    @Override
    public double CalculateTax(double AS) {
        if(AS>=400000.00)
          return ((AS*0.05)/12);
      else if(AS>600000.00)
          return ((AS*0.07)/12);
      else if((AS>2000000.00) || (AS>1500000.00))
          return ((AS *0.1)/12);
      else
          return 0.00;
    }
    public double Commission(double GrossSales,double CR)
    {
        return (this.getGrossSales()*this.getCommissionRate());
    }

    @Override
    public double HolidayBonus(double AS) {
        return (AS *0.05);
    }

    @Override
    public double AnnualBonus(double BS) {
       return (this.getBasicSalary()*0.1);
    }
    
    public boolean AddSalaryOfSalariedEmployee(String BS,String Ma,String Ca,String Gs,String T,String Pf,String D,String Ns ) {
        
        boolean b=false;
        
        String sql="insert into SalarySlip(BasicSalary,MedicalAllowance,ConveyanceAllowance,GrossSalary,Tax,ProvidentFund,Deductions,NetSalary)values('"+BS+"','"+Ma+"','"+Ca+"','"+Gs+"','"+T+"','"+Pf+"','"+D+"','"+Ns+"')";
        try
        {
           st=con_obj.createStatement();
           
           int rs=st.executeUpdate(sql);
           if(rs>0)
           {
               b=true;
           }
           else
           {
               b=false;
           }
        }
        catch(Exception ex)
        {
               JOptionPane.showMessageDialog(null, ex);
  
        }
        return b;
    }

    public boolean SearchSSalary(int id)
    {
        String salary="select * from SalarySlip where ID='"+id+"'";
         boolean b = false;
            try
            {             
            ps=con_obj.prepareStatement(salary);
            rs=ps.executeQuery();
            while(rs.next()){
                String BS=rs.getString("BasicSalary");
                String Ma=rs.getString("MedicalAllowance");
                String Ca=rs.getString("ConveyanceAllowance");
                String Gs=rs.getString("GrossSalary");
                String T=rs.getString("Tax");
                String Pf=rs.getString("ProvidentFund");
                String D=rs.getString("Deductions");
                String Ns=rs.getString("NetSalary");
            b=true;
            }
            }
            catch(Exception ex)
            {
                JOptionPane.showMessageDialog(null,ex);
                b=false;
            }
            return b;
            }
    
    }

   
