
package ems;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import java.sql.*;
import java.sql.DriverManager;


public class SalariedEmployee extends Employee {

    public SalariedEmployee(String fName, String lName, String contact, String age, String email, String dob, String gender, String address, String city, String cnic, String religion, String maritalStatus, String qualification, int yoj, int id) {
        super(fName, lName, contact, age, email, dob, gender, address, city, cnic, religion, maritalStatus, qualification, yoj, id);
    }
    ConnectionToDB con=new ConnectionToDB();
    Connection con_obj=con.EstablishConnection();
    Statement st=null;
    PreparedStatement ps=null;
    ResultSet rs=null;
    
    @Override
    public boolean AddUser(String fName, String lName, String contact, String email, String age, String dob, String gender, String cnic, String address, String maritalStatus, String qualification, String religion, String city, int yoj) {        
        boolean b=false;
        String sql="insert into SalariedEmployee(FirstName,LastName,Contact,Email,Age,DateOfBirth,Gender,CNIC,Address,MaritalStatus,Qualification,Religion,City,YearOfJoining)values('"+super.getfName()+"','"+super.getlName()+"','"+super.getContact()+"','"+super.getEmail()+"','"+super.getAge()+"','"+super.getDob()+"','"+super.getGender()+"','"+super.getCnic()+"','"+super.getAddress()+"','"+super.getMaritalStatus()+"','"+super.getQualification()+"','"+super.getReligion()+"','"+super.getCity()+"','"+super.getYoj()+"')";
        try
        {
           st=con_obj.createStatement();
           
           int rs=st.executeUpdate(sql);
           if(rs>0)
           {
               b=true;
           }
           else
           {
               b=false;
           }
        }
        catch(Exception ex)
        {
               JOptionPane.showMessageDialog(null, ex);
  
        }
        return b;
    }

    
    @Override
    public boolean FetchUser(int id)
{
  String loginString = "select * from SalariedEmployee where ID='"+id+"'";
            boolean b = false;
            try
            {             
            ps=con_obj.prepareStatement(loginString);
            rs=ps.executeQuery();
            while(rs.next()){
                
                String fName= rs.getString("FirstName");
                String lName = rs.getString("LastName");
                String contact = rs.getString("Contact");
                String email = rs.getString("Email");
                String age = rs.getString("Age");
                String dob = rs.getString("DateOfBirth");
                String gender = rs.getString("Gender");
                String cnic = rs.getString("CNIC");
                String address = rs.getString("Address");
                String maritalStatus = rs.getString("MaritalStatus");
                String qualification = rs.getString("Qualification");
                String religion = rs.getString("Religion");
                String city = rs.getString("City");
                int yoj = rs.getInt("YearOfJoining");

                
               
               
                b=true;
            }
            }
            catch(Exception ex)
            {
                JOptionPane.showMessageDialog(null,ex);
                b=false;
            }
            return b;



}

    @Override
    public boolean Delete(int id)
        {
            boolean b= false;
            String sql="delete from SalariedEmployee where ID ='"+id+"'";
            try
            {
                st=con_obj.createStatement();
           
         int rs = st.executeUpdate(sql);
         if(rs>0)
         {
              b = true;
         }
         else
         {
             b= false;
         }
           
            }
            catch(Exception ex)
            {
                 JOptionPane.showMessageDialog(null,ex);
            }
            return b;
        }      

}
