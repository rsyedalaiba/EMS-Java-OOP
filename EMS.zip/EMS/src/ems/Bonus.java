
package ems;

interface Bonus {
    public double HolidayBonus(double AS);
    public double AnnualBonus(double BS);
}
