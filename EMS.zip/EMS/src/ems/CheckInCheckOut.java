
package ems;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class CheckInCheckOut extends Attendance{
     ConnectionToDB con=new ConnectionToDB();
    Connection con_obj=con.EstablishConnection();
    Statement st=null;
    PreparedStatement ps=null;
    ResultSet rs=null;
    
     private String checkInDate,checkInstatus,checkOutDate,checkOutStatus;

    public ConnectionToDB getCon() {
        return con;
    }

    public void setCon(ConnectionToDB con) {
        this.con = con;
    }

    public Connection getCon_obj() {
        return con_obj;
    }

    public void setCon_obj(Connection con_obj) {
        this.con_obj = con_obj;
    }

    public Statement getSt() {
        return st;
    }

    public void setSt(Statement st) {
        this.st = st;
    }

    public PreparedStatement getPs() {
        return ps;
    }

    public void setPs(PreparedStatement ps) {
        this.ps = ps;
    }

    public ResultSet getRs() {
        return rs;
    }

    public void setRs(ResultSet rs) {
        this.rs = rs;
    }

    public String getCheckInDate() {
        return checkInDate;
    }

    public void setCheckInDate(String checkInDate) {
        this.checkInDate = checkInDate;
    }

    public String getCheckInstatus() {
        return checkInstatus;
    }

    public void setCheckInstatus(String checkInstatus) {
        this.checkInstatus = checkInstatus;
    }

    public String getCheckOutDate() {
        return checkOutDate;
    }

    public void setCheckOutDate(String checkOutDate) {
        this.checkOutDate = checkOutDate;
    }

    public String getCheckOutStatus() {
        return checkOutStatus;
    }

    public void setCheckOutStatus(String checkOutStatus) {
        this.checkOutStatus = checkOutStatus;
    }

    public CheckInCheckOut(String checkInDate, String checkInstatus, String checkOutDate, String checkOutStatus, int employeeID) {
        super(employeeID);
        this.checkInDate = checkInDate;
        this.checkInstatus = checkInstatus;
        this.checkOutDate = checkOutDate;
        this.checkOutStatus = checkOutStatus;
    }

   
     

     public boolean AddUserforcheckin(String checkInDate,String checkInStatus,String checkOutDate,String checkOutStatus) 
   {
        
       String sql="insert into CheckInCheckOut(CheckInDate,CheckInStatus,CheckOutDate,CheckOutStatus)values('"+this.getCheckInDate()+"','"+this.getCheckInstatus()+"','"+this.getCheckOutDate()+"','"+this.getCheckOutStatus()+"')";
    
       
       boolean b=false; 
       try
       {
          st=con_obj.createStatement();
       
          int res=st.executeUpdate(sql);
           if(res>0)
           {
//               JOptionPane.showMessageDialog(null,"Inserted");
               b=true;
           }
           else
           {
               b=false;
//              JOptionPane.showMessageDialog(null,"Error");
           }
       }
       catch(Exception ex)
       {
           JOptionPane.showMessageDialog(null, ex);
           b=false;
       }
       return b;
   }

    public boolean FetchUser(int id) {
        String loginString = "select * from CheckInCheckOut where EmployeeId='"+id+"'";
            boolean b = false;
            try
            {             
            ps=con_obj.prepareStatement(loginString);
            rs=ps.executeQuery();
            while(rs.next()){
                
                checkInDate=rs.getString("CheckInDate");
                checkInstatus=rs.getString("CheckInStatus");
                checkOutDate=rs.getString("CheckOutDate");
                checkOutStatus=rs.getString("CheckOutStatus");
                         
                b=true;
            }
            }
            catch(Exception ex)
            {
                JOptionPane.showMessageDialog(null,ex);
                b=false;
            }
            return b;
    }
    
    public boolean updateforcheckin(int id) 
   {
        boolean b=false;
      
       
        
       String updatequery="UPDATE CheckInCheckOut set employeename=?,departmentcode=?,checkindate=?,checkinstatus=? WHERE employeeid=?";
    
    
       try
       {
       ps=con_obj.prepareStatement(updatequery);
       int rs=ps.executeUpdate();
           if(rs>0)
           {
               JOptionPane.showMessageDialog(null,"Records Updated");
               b=true;
           }
           else
           {
               b=false;
              JOptionPane.showMessageDialog(null,"Error");
           }
       }
       catch(Exception ex)
       {
           JOptionPane.showMessageDialog(null, ex);
           b=false;
       }
      
            
              return b;
   }
    public void InsertIntoJTable(int id,String checkInDate,String checkInStatus,String checkOutDate,String checkOutStatus)
    {
        try{
        String query1="select * from CheckInCheckOut";
        st=con_obj.createStatement();
        rs=st.executeQuery(query1);
        
        }
        catch(Exception ex)
        {
            JOptionPane.showMessageDialog(null, ex);
        }
    }
}
