
package ems;

public class ProjectDetails {
    private int projectId,daysToComplete;
    private String projectName;

    //Getter and Setter
    public int getProjectId() {
        return projectId;
    }

    public void setProjectId(int projectId) {
        this.projectId = projectId;
    }

    public int getDaysToComplete() {
        return daysToComplete;
    }

    public void setDaysToComplete(int daysToComplete) {
        this.daysToComplete = daysToComplete;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    //Constructor
    public ProjectDetails(int projectId, int daysToComplete, String projectName) {
        this.projectId = projectId;
        this.daysToComplete = daysToComplete;
        this.projectName = projectName;
    }
    
    
    @Override
    public String toString()
    {
       return "\n-Project Details:\n"+ 
              "\nProject ID: "+this.getProjectId()+
               "\nProject Name: "+this.getProjectName()+
               "\nDays to Complete: "+this.getDaysToComplete();
    }
    
    
}
