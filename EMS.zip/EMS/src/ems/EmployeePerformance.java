
package ems;

import java.util.ArrayList;

public class EmployeePerformance {

    private double clientRating,teamMemberRating;
    private String Status;
    int count=0;
    ArrayList<ProjectDetails> prDetails=new ArrayList<>();
    
    //Getter and Setter
    public double getClientRating() {
        return clientRating;
    }

    public void setClientRating(double clientRating) {
        this.clientRating = clientRating;
    }

    public double getTeamMemberRating() {
        return teamMemberRating;
    }

    public void setTeamMemberRating(double teamMemberRating) {
        this.teamMemberRating = teamMemberRating;
    }

    
    public String getStatus() {
        return Status;
    }

    public void setStatus(String Status) {
        this.Status = Status;
    }  

    public ArrayList<ProjectDetails> getprDetails() {
        return prDetails;
    }

    public void setprDetails(ArrayList<ProjectDetails> prDetails) {
        this.prDetails = prDetails;
    }

    //Construcor

    public EmployeePerformance( double clientRating, double teamMemberRating, String Status,ProjectDetails pd) {
        this.clientRating = clientRating;
        this.teamMemberRating = teamMemberRating;
        this.Status = Status;
        this.prDetails.add(pd);
    }
    
    
    //Methods
    public void AssignProject(ProjectDetails pd){
        prDetails.add(pd);
    }
    
    public void Display()
    {        
        for (int i = 0; i <prDetails.size(); i++) 
        {     System.out.println("\n---Project "+(i+1)+" ---");
              ProjectDetails pd=prDetails.get(i);
              System.out.println(pd.toString());
              System.out.println("Project Status: "+this.getStatus()); 
              if(this.getStatus().equals("Completed"))
              {
              count=count+1;
              }              
              System.out.println("Client Ratings: "+this.getClientRating());
              System.out.println("Team Member Ratings: "+this.getTeamMemberRating());
              System.out.println("--------------------------------------------");              
        }        
              System.out.println("\nNo. of Project Completed: "+count);              
              System.out.println("--------------------------------------------");
              
            
        
    }
}
