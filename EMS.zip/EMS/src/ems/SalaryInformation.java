
package ems;

import java.util.ArrayList;

interface SalaryInformation extends Taxes,Bonus{
//    ArrayList<SalariedEmployee> s=new ArrayList<>();
//    ArrayList<SalariedEmployee> sList=s;

//    ArrayList<CommissionedEmployee> b=new ArrayList<>();
//    ArrayList<BasePlusCommissionEmployee> c=new ArrayList<>();
    
    public double CalculateMedicalAllowance(double basicSalary);        
    public double CalculateConveyanceAllowance(double basicSalary);
    public double CalculateGrossSalaray(double basicSalary,double MS,double CA);
    public double CalculateAnnualSalary(double GS);
    public double CalculateProvidentFund(double GS);
    public double CalculateDeductions(double Tax,double PF);
    public double CalculateNetSalary(double GS,double d);

    
    
    
    
}
