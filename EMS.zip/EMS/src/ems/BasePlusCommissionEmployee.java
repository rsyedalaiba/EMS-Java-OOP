
package ems;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;


public class BasePlusCommissionEmployee extends CommissionedEmployee {

    public BasePlusCommissionEmployee(String fName, String lName, String contact, String age, String email, String dob, String gender, String address, String city, String cnic, String religion, String maritalStatus, String qualification, int yoj, int id) {
        super(fName, lName, contact, age, email, dob, gender, address, city, cnic, religion, maritalStatus, qualification, yoj, id);
    }

    
    //Methods
//    @Override
//    public double CalculateMedicalAllowance()
//    {
//        return (this.getBaseSalary()*0.1);
//    }
//    @Override
//    public double CalculateConveyanceAllowance()
//    {
//        return (this.getBaseSalary()*0.15);
//    }
//    @Override
//    public double CalculateGrossSalaray()
//    {
//        return (this.getBaseSalary()+this.CalculateMedicalAllowance()+this.CalculateConveyanceAllowance());
//    }
//    @Override
//    public double CalculateAnnualSalary()
//    {
//        return (this.CalculateGrossSalaray()*12);
//    }
//    @Override
//    public double CalculateTax()
//    {
//      if(this.CalculateAnnualSalary()>=400000.00)
//          return ((this.CalculateAnnualSalary()*0.05)/12);
//      else if(this.CalculateAnnualSalary()>600000.00)
//          return ((this.CalculateAnnualSalary()*0.07)/12);
//      else if((this.CalculateAnnualSalary()>2000000.00) || (this.CalculateAnnualSalary()>1500000.00))
//          return ((this.CalculateAnnualSalary()*0.1)/12);
//      else
//          return 0.00;
//    }
//    @Override
//    public double CalculateProvidentFund()
//    {
//       if(super.getEmpGender()== "female" || super.getEmpGender()== "Female")
//       {
//           if(super.getEmpYearOfJoining()-super.currentYear <=3)
//           {
//              return ((this.CalculateGrossSalaray()-0.08))/12;
//           }
//           else
//              return ((this.CalculateGrossSalaray()-0.01))/12;
//
//       }
//       else
//        return ((this.CalculateGrossSalaray()-0.01))/12;
//    }
//    @Override
//    public double CalculateDeductions()
//    {
//        return (this.CalculateTax()+this.CalculateProvidentFund());
//    }
//    @Override
//     public double CalculateNetSalary()
//    {
//     return ((this.CalculateGrossSalaray()+super.Commission())-this.CalculateDeductions());
//    }
//     @Override
//    public double HolidayBonus() {
//        return (this.CalculateAnnualSalary()*0.05);
//    }
//
//    @Override
//    public double AnnualBonus() {
//         return (this.getBaseSalary()*0.1);
//    }
//    
//        public String Salary()
//    {                
//        return  "-Salaray Details: "+
//                "\nBasic Salary |"+this.getBaseSalary()+
//                "\nMedical Allowance |"+this.CalculateMedicalAllowance()+
//                "\nConveyance Allowance |"+this.CalculateConveyanceAllowance()+
//                "\nGross Sales |"+super.getGrossSales()+
//                "\nCommission Rate |"+super.getCommissionRate()+
//                "\n----------------------------------------------"+
//                "\n-Deductions: "+
//                "\nTaxes |"+this.CalculateTax()+
//                "\nProvident Fund |"+this.CalculateProvidentFund()+
//                "\nTotal Deduction |"+this.CalculateDeductions()+
//                "\n----------------------------------------------"+
//                "\n-Salary Slip: "+
////                "\nGross Salary |"+this.CalculateGrossSalaray()+
////                 "\nCommission |"+super.Commission()+
////                "\nDeductions |"+this.CalculateDeductions()+
//                super.Earnings()+
//                "\nNet Salary |"+this.CalculateNetSalary()+
//                "\n--------------------------------------------"+
//                "-\nAnnual Bonus |"+this.AnnualBonus();
//                }
    ConnectionToDB con=new ConnectionToDB();
    Connection con_obj=con.EstablishConnection();
    Statement st=null;
    PreparedStatement ps=null;
    ResultSet rs=null;
    
    @Override
    public boolean AddUser(String fName, String lName, String contact, String email, String age, String dob, String gender, String cnic, String address, String maritalStatus, String qualification, String religion, String city, int yoj) {
        boolean b=false;
        String sql="insert into BasePlusCommissionEmployee(FirstName,LastName,Contact,Email,Age,DateOfBirth,Gender,CNIC,Address,MaritalStatus,Qualification,Religion,City,YearOfJoining)values('"+super.getfName()+"','"+super.getlName()+"','"+super.getContact()+"','"+super.getEmail()+"','"+super.getAge()+"','"+super.getDob()+"','"+super.getGender()+"','"+super.getCnic()+"','"+super.getAddress()+"','"+super.getMaritalStatus()+"','"+super.getQualification()+"','"+super.getReligion()+"','"+super.getCity()+"','"+super.getYoj()+"')";
        try
        {
           st=con_obj.createStatement();
           
           int rs=st.executeUpdate(sql);
           if(rs>0)
           {
               b=true;
           }
           else
           {
               b=false;
           }
        }
        catch(Exception ex)
        {
               JOptionPane.showMessageDialog(null, ex);
  
        }
        return b;
    }

    @Override
    public boolean FetchUser(int id) {
        String loginString = "select * from BasePlusCommissionEmployee where ID='"+id+"'";
            boolean b = false;
            try
            {             
            ps=con_obj.prepareStatement(loginString);
            rs=ps.executeQuery();
            while(rs.next()){
                
               String fName= rs.getString("FirstName");
              String  lName = rs.getString("LastName");
              String  contact = rs.getString("Contact");
              String  email = rs.getString("Email");
              String  age = rs.getString("Age");
              String  dob = rs.getString("DateOfBirth");
              String  gender = rs.getString("Gender");
              String  cnic = rs.getString("CNIC");
             String   address = rs.getString("Address");
              String  maritalStatus = rs.getString("MaritalStatus");
              String  qualification = rs.getString("Qualification");
              String  religion = rs.getString("Religion");
             String   city = rs.getString("City");
               int yoj = rs.getInt("YearOfJoining");
//                super.dept=rs.getString("Department");
//                super.code=rs.getString("DepartmentCode");              
                b=true;
            }
            }
            catch(Exception ex)
            {
                JOptionPane.showMessageDialog(null,ex);
                b=false;
            }
            return b;
    }
    
    @Override
    public boolean Delete(int id)
        {
            boolean b= false;
            String sql="delete from BasePlusCommissionEmployee where ID ='"+id+"'";
            try
            {
                st=con_obj.createStatement();
           
         int rs = st.executeUpdate(sql);
         if(rs>0)
         {
              b = true;
         }
         else
         {
             b= false;
         }
           
            }
            catch(Exception ex)
            {
                 JOptionPane.showMessageDialog(null,ex);
            }
            return b;
        }     

}
