
package ems;

interface Taxes {
    public double CalculateTax(double AS);
}
