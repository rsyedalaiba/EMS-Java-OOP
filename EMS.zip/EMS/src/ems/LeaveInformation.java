
package ems;

import java.util.ArrayList;


public class LeaveInformation {
    private String Reason;
    int dateFrom,dateTo;
     ArrayList<SalariedEmployee> sLeaveInfo=new ArrayList<>();
     ArrayList<CommissionedEmployee> cLeaveInfo=new ArrayList<>();
     ArrayList<BasePlusCommissionEmployee> bLeaveInfo=new ArrayList<>();
   

     //Getter Setter
    public ArrayList<SalariedEmployee> getsLeaveInfo() {
        return sLeaveInfo;
    }

    public void setsLeaveInfo(ArrayList<SalariedEmployee> sLeaveInfo) {
        this.sLeaveInfo = sLeaveInfo;
    }

    public ArrayList<CommissionedEmployee> getcLeaveInfo() {
        return cLeaveInfo;
    }

    public void setcLeaveInfo(ArrayList<CommissionedEmployee> cLeaveInfo) {
        this.cLeaveInfo = cLeaveInfo;
    }

    public ArrayList<BasePlusCommissionEmployee> getbLeaveInfo() {
        return bLeaveInfo;
    }

    public void setbLeaveInfo(ArrayList<BasePlusCommissionEmployee> bLeaveInfo) {
        this.bLeaveInfo = bLeaveInfo;
    }
     
    
     
//    public void setEName(String EName) {
//        this.EName = EName;
//    }
//
//    public void setEdepartment(String Edepartment) {
//        this.Edepartment = Edepartment;
//    }

    public void setReason(String Reason) {
        this.Reason = Reason;
    }

    public int getDateFrom() {
        return dateFrom;
    }

    public void setDateFrom(int dateFrom) {
        this.dateFrom = dateFrom;
    }

    public int getDateTo() {
        return dateTo;
    }

    public void setDateTo(int dateTo) {
        this.dateTo = dateTo;
    }

    

    

//    public String getEName() {
//        return EName;
//    }
//
//    public String getEdepartment() {
//        return Edepartment;
//    }

    public String getReason() {
        return Reason;
    }

    
    
    //Consructor
    public LeaveInformation(String Reason, int dateFrom, int dateTo) {    
        this.Reason = Reason;
        this.dateFrom = dateFrom;
        this.dateTo = dateTo;
    }

    //Methods
    public void SalariedLeaveInfo(SalariedEmployee s) {
        this.sLeaveInfo.add(s);
    }
    public void CommissionedLeaveInfo(CommissionedEmployee c){
        
        this.cLeaveInfo.add(c);
        
    }
    public void BasePlusCommissionLeaveLeaveInfo(BasePlusCommissionEmployee b){
        
       
        this.bLeaveInfo.add(b);
        
    }
    public int Duration()
    {
        return (this.getDateTo()-this.getDateFrom());
    }
    
//    public void DisplayInfo(){
//          
//        for (int i = 0; i< sLeaveInfo.size() ; i++) {
//           
//            System.out.println("\n---Leave Information "+(i+1)+" ---");
//            SalariedEmployee s=sLeaveInfo.get(i);
//            System.out.println("Reason: "+this.getReason());
//            System.out.println("Dates Requested: From: "+this.getDateFrom()+"    To: "+this.getDateTo());
//            if(this.getReason() == "Maternity")
//            {
//                if(s.getEmpGender() == "Female" )
//                {
//                    if((s.currentYear - s.getEmpYearOfJoining()) >1)
//                    {
//                        System.out.println("Approved");
//                    }
//                    else
//                    {
//                        System.out.println("Rejected");
//                    }
//                }
//                    
//            }
//            else if(this.getReason() == "Sick")
//            {
//                if(this.Duration() <=7)
//                {
//                    System.out.println("Approved");
//                }
//                else
//                    {
//                        System.out.println("Rejected. You can only have minimum of 7 days leave");
//                    }                
//            }
//        }
//         System.out.println("\n-------------------------------------------");
//    }
}
