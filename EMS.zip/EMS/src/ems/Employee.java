
package ems;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;

public abstract class Employee {

    ConnectionToDB con=new ConnectionToDB();
    Connection con_obj=con.EstablishConnection();
    Statement st=null;
    PreparedStatement ps=null;
    ResultSet rs=null;
    
     private String fName, lName,contact,age,email,dob,gender,address,city,cnic,religion,maritalStatus,qualification;
     private int yoj,id;
//     private Department d;

    public Employee(String fName, String lName, String contact, String age, String email, String dob, String gender, String address, String city, String cnic, String religion, String maritalStatus, String qualification, int yoj, int id) {
        this.fName = fName;
        this.lName = lName;
        this.contact = contact;
        this.age = age;
        this.email = email;
        this.dob = dob;
        this.gender = gender;
        this.address = address;
        this.city = city;
        this.cnic = cnic;
        this.religion = religion;
        this.maritalStatus = maritalStatus;
        this.qualification = qualification;
        this.yoj = yoj;
        this.id = id;
    }

     
   



   

    


    
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }    
    public String getfName() {
        return fName;
    }

    public void setfName(String fName) {
        this.fName = fName;
    }

    public String getlName() {
        return lName;
    }

    public void setlName(String lName) {
        this.lName = lName;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCnic() {
        return cnic;
    }

    public void setCnic(String cnic) {
        this.cnic = cnic;
    }

    public String getReligion() {
        return religion;
    }

    public void setReligion(String religion) {
        this.religion = religion;
    }

    public String getMaritalStatus() {
        return maritalStatus;
    }

    public void setMaritalStatus(String maritalStatus) {
        this.maritalStatus = maritalStatus;
    }

    public String getQualification() {
        return qualification;
    }

    public void setQualification(String qualification) {
        this.qualification = qualification;
    }

    public int getYoj() {
        return yoj;
    }

    public void setYoj(int yoj) {
        this.yoj = yoj;
    }
    
    public abstract boolean AddUser(String fName ,String lName,String contact,String email,String age,String dob,String gender,String cnic,String address,String maritalStatus,String qualification,String religion,String city,int yoj);

    public abstract boolean FetchUser(int id);
    
    public abstract boolean Delete(int id);
}
