
package ems;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class AdminLogin {
    ConnectionToDB con=new ConnectionToDB();
    Connection con_obj=con.EstablishConnection();
    Statement st=null;
    PreparedStatement ps=null;
    ResultSet rs=null;
    
    public boolean Login(String userName,String userPassword)
    {
        String loginString="select * from AdminLogin where Username='"+userName+"' and Password='"+userPassword+"'";
        boolean b;
        try
        {
           ps= con_obj.prepareStatement(loginString);
           rs=ps.executeQuery();
           if(rs.next())
           {
               b=true;
           }
           else
           {
               b=false;
           }
        }
        catch(Exception ex)
        {
            b=false;
            JOptionPane.showMessageDialog(null, ex);
        }
        return b;
    }
}
