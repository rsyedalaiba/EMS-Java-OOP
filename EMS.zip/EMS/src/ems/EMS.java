
package ems;


public class EMS {
    public static void main(String[] args) {
//        BasePlusCommissionEmployee b1=new BasePlusCommissionEmployee( 90000,250,15, "091", "Laiba", "Rehman", "03152794456", "laiba@xyz.com", "21", "16-08-2001", "Female", "11-111-1111", "Madina Blessing", "Single", "Bachelors", "Islam", "Karachi", 2023, 2021);
//        BasePlusCommissionEmployee b2= new BasePlusCommissionEmployee(800000, 250, 10, null, null, null, null, null, null, null, null, null, null, null, null, null, null, 2023, 2021);

//        System.out.println(b1.toString());
//        System.out.println(b1.Salary());
//        ProjectDetails pd = new ProjectDetails(120, 15, "Hospital Management System");
//        ProjectDetails pd2 = new ProjectDetails(130, 10, "Pharmacy Management System");
//
//        EmployeePerformance ep=new EmployeePerformance(8, 7, "Completed", pd);
//        ep.AssignProject(pd2);
//        ep.Display();
//        CommissionedEmployee c1=new CommissionedEmployee(300, 10, "Commissioned", "065", "Amna", "Ramzan", "01370928748", "ammna@xyz.com", "19", "19-11-2003", "Female", "22-222-2222", "Madina Blessing", "Engaged", "Bachelors", "Islam", "Karachi", 2019);
//        SalariedEmployee s1=new SalariedEmployee(70000, "Salaried","091", "Laiba", "Rehman", "017363463456", "laiba@xyz.com", "21", "16-08-2001", "Female", "11-111-1111", "Madina Blessing", "Single", "Bachelors", "Islam", "Karachi",  2020);
//        BasePlusCommissionEmployee b1=new BasePlusCommissionEmployee(50000, 100, 5, "?Base Plus Commission", "069", "Laiba", "Tariq", "01836836846", "tariq@xyz.com", "19", "4-5-2003", "Female", "33-333-3333", "Malir Cantt", "Single", "MTech", "Islam", "Karachi", 2021);
//        Promotion p1=new Promotion(s1, c1, b1, ep);
////        SalariedEmployee s2=new SalariedEmployee(70000, "Salaried",p1, "091", "Laiba", "Rehman", "017363463456", "laiba@xyz.com", "21", "16-08-2001", "Female", "11-111-1111", "Madina Blessing", "Single", "Bachelors", "Islam", "Karachi", 2023, 2020);
//        
//        System.out.println(s1.toString());
//        System.out.println(s1.Salary());
//        System.out.println(p1.Increment());
    }
    
}
